/**
 * 
 */

$(function(){
	$("button:eq(0)").click(function(){
		location.href = 'introduce.html';
	})
	
	$("button:eq(1)").click(function(){
		location.href = 'dokdovideo.html';
	})
	
	$("button:eq(2)").click(function(){
		location.href = 'dokdoaudio.html';
	})
	
	$("button:eq(3)").click(function(){
		location.href = 'dokdoimages.html';
	})
})