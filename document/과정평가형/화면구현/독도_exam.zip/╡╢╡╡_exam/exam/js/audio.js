/**
 * 
 */

$(function(){
	$("#dialog_header").find("button").click(function(){
		$("#dialog_wrap").hide();
	})
	
	$("#dokdo_index").click(function(){
		location.href = 'index.html';
	})
})