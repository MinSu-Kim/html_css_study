/**
 * 
 */

$(function(){
	$("#dokdo_index").click(function(){
		location.href = 'index.html';
	})
})